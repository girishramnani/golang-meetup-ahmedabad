package mapped_mutex

import (
	"fmt"
	"testing"
)

func HammerMutex(m *MappedMutex, loops int, cdone chan bool) {
	for i := 0; i < loops; i++ {
		m.Lock(fmt.Sprintln(i))
		m.Unlock(fmt.Sprintln(i))
	}
	cdone <- true
}

func TestMutex(t *testing.T) {
	m := NewMappedMutex()
	c := make(chan bool)
	for i := 0; i < 10; i++ {
		go HammerMutex(m, 1000, c)
	}
	for i := 0; i < 10; i++ {
		<-c
	}
	if len(m.lockMap) != 1000 {
		t.Fatal("the mapMutex has less mutex present. Present :", len(m.lockMap))
	}
}

func TestMutexPanic(t *testing.T) {
	defer func() {
		if recover() != nil {
			t.Fatal("the mutex paniced")
		}
	}()
	mu := NewMappedMutex()
	mu.Lock("1")
	mu.Unlock("1")
	mu.Unlock("1")
}
