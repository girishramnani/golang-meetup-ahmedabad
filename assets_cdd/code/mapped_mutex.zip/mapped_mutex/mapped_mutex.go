package mapped_mutex

type MappedMutex struct {
}


